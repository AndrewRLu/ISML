//for integrate pipe + DMA

`timescale 1 ps / 1 ps

module top (
    // FrontPanel Host Interface (Matches .xdc exactly)
    input  wire [4:0]  okUH,
    output wire [2:0]  okHU,
    inout  wire [31:0] okUHU,
    inout  wire        okAA,

    // System Clock (Renamed to match .xdc)
    input  wire        sys_clk_n,
    input  wire        sys_clk_p,

    // LEDs (Renamed to match .xdc)
    output wire [7:0]  led,
    // output wire [0:0] led,
    // output wire [7:0] scrap,

    // DRAM Interface (Matches .xdc exactly)
    output wire [14:0] ddr3_addr,
    output wire [2:0]  ddr3_ba,
    output wire        ddr3_cas_n,
    output wire [0:0]  ddr3_ck_n,
    output wire [0:0]  ddr3_ck_p,
    output wire [0:0]  ddr3_cke,
    output wire [3:0]  ddr3_dm,
    inout  wire [31:0] ddr3_dq,
    inout  wire [3:0]  ddr3_dqs_n,
    inout  wire [3:0]  ddr3_dqs_p,
    output wire [0:0]  ddr3_odt,
    output wire        ddr3_ras_n,
    output wire        ddr3_reset_n,
    output wire        ddr3_we_n,

    //ext reset
    input wire         ext_reset_in_0
);

    //------------------------------------------------------------------------
    // Opal Kelly Host Interface & Endpoints
    //------------------------------------------------------------------------
    wire        okClk;
    wire [112:0] okHE;
    wire [64:0] okEH;

    // assign okEH = 33'h0;
    
    okHost host (
        .okUH(okUH),
        .okHU(okHU),
        .okUHU(okUHU),
        .okAA(okAA),
        .okClk(okClk),
        .okHE(okHE),
        .okEH(okEH)
    );
    
    wire [64:0]  okEH_wireOut20;
    wire [64:0]  okEH_pipeIn9C;

    okWireOR # (.N(2)) wireOR (
        .okEH(okEH), 
        .okEHx({
            okEH_wireOut20,
            okEH_pipeIn9C
        })
    );

    wire [31:0] usb_in;
    wire [31:0] usb_out;

    okWireIn wireIn00 (
        .okHE(okHE),
        .ep_addr(8'h00), 
        .ep_dataout(usb_in)
    );

    okWireOut wireOut20 (
        .okHE(okHE),
        .okEH(okEH_wireOut20),
        .ep_addr(8'h20), 
        .ep_datain(usb_out)
    );


    //----------------
    // pipe, DMA cycle
    //----------------
    wire ui_clk;

    wire [0:0] gpio_enable_DMA_tri_i;
    wire [0:0] gpio_enable_pipe_tri_o;

    reg [0:0] reg_gpio_enable_DMA_tri_i;
    // assign gpio_enable_DMA_tri_i = reg_gpio_enable_DMA_tri_i;

    // gpio_enable_pipe_tri_o: ui_clk -> okClk, consumed by FSM
    wire sync_enable_pipe;

    xpm_cdc_single #(
        .DEST_SYNC_FF   (2),
        .INIT_SYNC_FF   (0),
        .SIM_ASSERT_CHK (0),
        .SRC_INPUT_REG  (0)   // set 1 if you want an extra reg on ui_clk side first
    ) xpm_cdc_enable_pipe (
        .src_clk  (1'b0),      // unused when SRC_INPUT_REG=0
        .src_in   (gpio_enable_pipe_tri_o),
        .dest_clk (okClk),
        .dest_out (sync_enable_pipe)
    );

    xpm_cdc_single #(.DEST_SYNC_FF(2), .INIT_SYNC_FF(0), .SIM_ASSERT_CHK(0), .SRC_INPUT_REG(0))
    xpm_cdc_enable_dma (
        .src_clk  (1'b0),
        .src_in   (reg_gpio_enable_DMA_tri_i),  // okClk domain
        .dest_clk (ui_clk),
        .dest_out (gpio_enable_DMA_tri_i)        // now safely in ui_clk domain
    );

    //FSM (for switch between pipe and DMA; see FSM.md)

    //number of transfer chunks
    wire [31:0] gpio_num_chunks_tri_i;
    reg [31:0] num_chunks_trans = 32'b0;
    
    //states
    reg [1:0] state;
    localparam S_PIPEIN         = 2'b00;
    localparam S_WAIT_LAST_BLOCK= 2'b01;
    localparam S_DMA            = 2'b10;
    localparam S_DONE           = 2'b11;

    wire [0:0] gpio_s_done_tri_i;
    reg [0:0] reg_gpio_s_done_tri_i = 1'b0;
    // assign gpio_s_done_tri_i = reg_gpio_s_done_tri_i; 

    xpm_cdc_single #(.DEST_SYNC_FF(2), .INIT_SYNC_FF(0), .SIM_ASSERT_CHK(0), .SRC_INPUT_REG(0))
    xpm_cdc_s_done (
        .src_clk  (1'b0),
        .src_in   (reg_gpio_s_done_tri_i),  // okClk domain
        .dest_clk (ui_clk),
        .dest_out (gpio_s_done_tri_i)        // now safely in ui_clk domain
    );

    okWireIn wireIn01 (
        .okHE(okHE),
        .ep_addr(8'h01), 
        .ep_dataout(gpio_num_chunks_tri_i)
    );

    //counters;
    reg [3:0] num_blocks_transferred; // num blocks transfered by bt pipe

    // pipe into BRAM
    //----------------

    wire [31:0] ep9Cpipe;
    wire ep9Cwrite;
    wire ep9Cstrobe;

    
    wire ep9Cready;
    // assign ep9Cready = (num_blocks_transferred != 4'd8) && (!reg_gpio_enable_DMA_tri_i); // ready when DMA is disabled and when not on last block
    assign ep9Cready = (state == S_PIPEIN); //this is a lot smarter, just enable when in intended state :)

    reg [10:0] write_addr_counter; 
    wire [31:0] BRAM_PORTA_0_addr;

    // assign BRAM_PORTA_0_addr = {21'b0, write_addr_counter};   // zero-pad the unused upper bits (word address)
    assign BRAM_PORTA_0_addr = {19'b0, write_addr_counter, 2'b00}; //byte address ; so ig shift up by 2 bits to make it word each time

    okBTPipeIn pipeIn9C (
        .okHE(okHE), 
        .okEH(okEH_pipeIn9C),
        .ep_addr(8'h9c), 
        .ep_dataout(ep9Cpipe), 
        .ep_write(ep9Cwrite),
        .ep_blockstrobe(ep9Cstrobe), 
        .ep_ready(ep9Cready)
    );

    // FSM
    //---------------

    always @(posedge okClk or posedge ext_reset_in_0) begin
        if (ext_reset_in_0) begin
            // reset BRAM address
            state         <= S_PIPEIN;
            write_addr_counter <= 11'd0;
            reg_gpio_enable_DMA_tri_i <= 1'b0;
            num_blocks_transferred <= 4'b0;
        end else begin
            case (state)
                S_PIPEIN: begin
                    // write data in (dont touch EP_READY), need to increment
                    // check for strobe: write more or transfer to next S
                        // increment count on strobe
                        // increment BRAM address when EP_WRITE asserted
                    if (ep9Cwrite) begin
                        write_addr_counter <= write_addr_counter + 1'b1; // next word
                    end 

                    if (ep9Cstrobe) begin
                        num_blocks_transferred <= num_blocks_transferred + 4'b1;
                        if (num_blocks_transferred == 4'd7) begin
                            state <= S_WAIT_LAST_BLOCK; //bad documentation, hoping that strobe happens  
                                                        //after EP_READY is read for last block 
                                                        //(so can dessert to prevent next transfer)
                        end
                    end
                end

                S_WAIT_LAST_BLOCK: begin
                    //dessert EP_READY, 
                    //wait for write to go low (write last block): trasfer to next S
                    
                    if (ep9Cwrite) begin
                        write_addr_counter <= write_addr_counter + 1'b1; // next word
                        if (write_addr_counter == 11'd2047) begin //done when last word being written
                            reg_gpio_enable_DMA_tri_i <= 1'b1;
                            state <= S_DMA;
                        end
                    end
                end

                S_DMA: begin
                    //assert DMA to go
                    //poll GPIO: transfer to next S
                    if (sync_enable_pipe) begin
                        //counter cleanup
                        write_addr_counter <= 11'd0;
                        num_blocks_transferred <= 4'b0;

                        //flip signal
                        reg_gpio_enable_DMA_tri_i <= 1'b0;
                        
                        //next state
                        state <= S_PIPEIN;

                        num_chunks_trans <= num_chunks_trans + 32'b1;
                        if (num_chunks_trans == gpio_num_chunks_tri_i - 1) begin
                            state <= S_DONE;
                            reg_gpio_s_done_tri_i <= 1'd1;
                        end
                    end
                end

                S_DONE: begin
                    // rest of execution
                end

            endcase
        end
    end

    //------------------------------------------------------------------------
    // Vivado Block Design Wrapper Instance
    //------------------------------------------------------------------------
    design_1_wrapper d1 (
        // Host-to-Target Data Path
        .GPIO_0_tri_i(usb_in),
        .GPIO2_0_tri_o(usb_out),
        
        // Target Hardware Control Path (Routed to renamed LED wire)
        .GPIO_1_tri_o(led),
        
        // Clocking (Routed to renamed system clock pins)
        .fixed_200mhz_clk_n(sys_clk_n),
        .fixed_200mhz_clk_p(sys_clk_p),

        // DDR3 Physical Ports
        .ddr3_addr(ddr3_addr),
        .ddr3_ba(ddr3_ba),
        .ddr3_cas_n(ddr3_cas_n),
        .ddr3_ck_n(ddr3_ck_n),
        .ddr3_ck_p(ddr3_ck_p),
        .ddr3_cke(ddr3_cke),
        .ddr3_dm(ddr3_dm),
        .ddr3_dq(ddr3_dq),
        .ddr3_dqs_n(ddr3_dqs_n),
        .ddr3_dqs_p(ddr3_dqs_p),
        .ddr3_odt(ddr3_odt),
        .ddr3_ras_n(ddr3_ras_n),
        .ddr3_reset_n(ddr3_reset_n),
        .ddr3_we_n(ddr3_we_n),
        .ext_reset_in_0(ext_reset_in_0),

        //BRAM pipe in
        .BRAM_PORTA_0_addr(BRAM_PORTA_0_addr), //word addressed
        .BRAM_PORTA_0_clk(okClk),
        .BRAM_PORTA_0_din(ep9Cpipe),
        .BRAM_PORTA_0_dout(),
        .BRAM_PORTA_0_en(1'b1),
        .BRAM_PORTA_0_rst(1'b0),
        .BRAM_PORTA_0_we({4{ep9Cwrite}}),

        //GPIO for FSM poll
        .gpio_enable_DMA_tri_i(gpio_enable_DMA_tri_i), //default value 0
        .gpio_enable_pipe_tri_o(gpio_enable_pipe_tri_o), //default value 0; not 1 to prevent S_DMA from transitioning to next state too early for first instance (if 1, would skip first DMA transfer entirely)

        //GPIO for num chunks and state done
        .gpio_num_chunks_tri_i(gpio_num_chunks_tri_i),
        .gpio_s_done_tri_i(gpio_s_done_tri_i),

        //mig clock
        .ui_clk(ui_clk)
    );

endmodule