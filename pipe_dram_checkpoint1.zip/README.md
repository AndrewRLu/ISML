# NOTE: only verified with MB code (NOT piped back), so like 95% sure it works :)

can pipe in one large chunk,

in future probably have to make a way to put in specific areas of DRAM